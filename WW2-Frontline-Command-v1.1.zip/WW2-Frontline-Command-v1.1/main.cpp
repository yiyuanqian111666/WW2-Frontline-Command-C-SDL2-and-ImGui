﻿#define NOMINMAX
#pragma execution_character_set("utf-8")

#include <SDL.h>
#include <cmath>
#include <vector>
#include <cstdlib>
#include <algorithm>
#include <string>
#include <map>
#include <fstream>
#include <windows.h>
#include <mmsystem.h>

#pragma comment(lib, "winmm.lib")

#include "imgui.h"
#include "imgui_impl_sdl2.h"
#include "imgui_impl_sdlrenderer2.h"

// ==========================================
// 1. 常量与枚举定义
// ==========================================
const float VIEW_WIDTH = 1280.0f;
const float VIEW_HEIGHT = 900.0f;
const float MAP_WIDTH = 3600.0f;
const float MAP_HEIGHT = 2400.0f;

enum GameState {
    STATE_MENU_SELECT = 0,
    STATE_PLAYING = 1,
    STATE_GAMEOVER = 2
};

enum GameMode {
    MODE_1V1 = 0,
    MODE_2V2 = 1,
    MODE_BATTLE_ROYALE = 2,
    MODE_ZOMBIE_STAND = 3
};

enum Faction {
    FACTION_AXIS = 0,
    FACTION_ALLIES = 1,
    FACTION_ZOMBIE = 2
};

enum Nation {
    NATION_US = 0,
    NATION_SOVIET = 1,
    NATION_UK = 2,
    NATION_GERMANY = 3,
    NATION_JAPAN = 4,
    NATION_ITALY = 5,
    NATION_FRANCE = 6,
    NATION_ZOMBIE_HORDE = 7
};

enum TacticalOrder {
    ORDER_ADVANCE = 0,
    ORDER_ATTACK_MOVE = 1,
    ORDER_CHARGE = 2,
    ORDER_CAPTURE = 3,
    ORDER_DEFEND = 4,
    ORDER_MOVE_TO = 5
};

enum UnitType {
    UNIT_SCOUT = 0,
    UNIT_INFANTRY,
    UNIT_AIRBORNE,
    UNIT_HMG,
    UNIT_PIONEER,
    UNIT_MORTAR,
    UNIT_AT_GUN,
    UNIT_SHERMAN,
    UNIT_TANK_DESTROYER,
    UNIT_HEAVY_TANK,
    UNIT_ARTILLERY,
    UNIT_SUPER_HEAVY,
    UNIT_SNIPER,
    UNIT_AA_HALFTRACK,
    UNIT_MOBILE_PILLBOX,
    UNIT_TESLA_MECH,
    UNIT_FLAMETHROWER,
    UNIT_ZOMBIE_WALKER,
    UNIT_ZOMBIE_RUNNER,
    UNIT_ZOMBIE_BRUTE
};

enum CommandSkillType {
    SKILL_NONE = 0,
    SKILL_AIRSTRIKE,
    SKILL_SMOKE_SCREEN
};

// ==========================================
// 2. 结构体与动态背景粒子
// ==========================================
struct MenuParticle {
    float x, y;
    float vx, vy;
    float size;
    float life, maxLife;
    SDL_Color color;
    bool isSmoke;
};

struct River { float x, y, w, h; };
struct Bridge { float x, y, w, h; };

struct Camera {
    float x = 1800.0f;
    float y = 1500.0f;
    float shakeTimer = 0.0f;
    float shakeIntensity = 0.0f;
};

struct CapturePoint {
    std::string nameCn;
    float x, y, radius;
    int owner;
    Nation ownerNation;
    float captureProgress;
    bool hasCapitolHQ;
};

struct Fortification {
    float x, y;
    int hp, maxHp;
    bool isEnemyTeam;
    bool active = true;
    float flashTimer = 0.0f;
};

struct SmokeArea {
    float x, y, radius;
    float life;
    bool active = true;
};

struct ImpactParticle {
    float x, y;
    float vx, vy;
    float life, maxLife;
    SDL_Color color;
    bool active = true;
};

struct Bullet {
    float x, y;
    float vx, vy;
    int damage;
    bool isEnemyTeam;
    float life;
    bool active;
};

struct CapitolHQ {
    float x, y;
    int hp, maxHp;
    bool isEnemyTeam;
    float flashTimer = 0.0f;
};

struct Actor {
    float x, y;
    float speed;
    int hp, maxHp;
    int attack;
    int defense;
    bool isEnemyTeam;
    bool isAllyAI = false;
    UnitType uType;
    Nation nation;

    float fireRate = 0.5f;
    int maxClipAmmo = 10;
    int currentClipAmmo = 10;
    float reloadTimeMax = 2.0f;
    float currentReloadTimer = 0.0f;
    bool isReloading = false;

    float attackCooldown = 0.0f;
    float attackRange;
    float deathTimer = 0.0f;
    bool isDead = false;

    float flashTimer = 0.0f;
    float recoilOffset = 0.0f;
    float skillCooldown = 0.0f;
    float suppressionValue = 0.0f;

    TacticalOrder currentOrder = ORDER_ADVANCE;
    float targetDestX = 0.0f;
    float targetDestY = 0.0f;
    bool hasCustomTarget = false;
    bool isSelectedByPlayer = false;
    float radius = 14.0f;
};

enum RarityTier {
    TIER_NORMAL = 0,
    TIER_ADVANCED = 1,
    TIER_LEGENDARY = 2
};

struct Card {
    UnitType uType;
    std::string nameEn;
    std::string nameCn;
    std::string descCn;
    int supplyCost;
    int spawnCount;
    float cooldownMax;
    float currentCooldown = 0.0f;
    SDL_Color cardColor;
    bool isSelectedForDeck = false;
    bool isGachaUnlocked = false;
    RarityTier rarity = TIER_NORMAL;
};

// ==========================================
// 3. 音效与存档系统
// ==========================================
void PlaySoundEffect(const std::string& soundName) {
    if (soundName == "click") {
        MessageBeep(MB_ICONASTERISK);
    }
    else if (soundName == "deploy") {
        MessageBeep(MB_OK);
    }
    else if (soundName == "gacha") {
        PlaySound(TEXT("SystemExclamation"), NULL, SND_ASYNC | SND_ALIAS);
    }
    else if (soundName == "airstrike") {
        PlaySound(TEXT("SystemHand"), NULL, SND_ASYNC | SND_ALIAS);
    }
    else if (soundName == "build") {
        MessageBeep(MB_ICONQUESTION);
    }
    else {
        MessageBeep(MB_OK);
    }
}

Faction GetNationFaction(Nation n) {
    if (n == NATION_GERMANY || n == NATION_JAPAN || n == NATION_ITALY) return FACTION_AXIS;
    if (n == NATION_ZOMBIE_HORDE) return FACTION_ZOMBIE;
    return FACTION_ALLIES;
}

// 严密的地图边界空气墙校验（防止单位和鼠标越界）
bool IsInAirWallBoundary(float x, float y) {
    if (x < 50.0f || x > MAP_WIDTH - 50.0f) return true;
    if (y < 50.0f || y > MAP_HEIGHT - 50.0f) return true;
    return false;
}

bool IsInRiverWater(float x, float y, const std::vector<River>& rivers, const std::vector<Bridge>& bridges) {
    for (const auto& b : bridges) {
        if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) return false;
    }
    for (const auto& r : rivers) {
        if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) return true;
    }
    return false;
}

void SpawnImpactSparks(std::vector<ImpactParticle>& particles, float x, float y, int count, SDL_Color col) {
    for (int i = 0; i < count; ++i) {
        float angle = static_cast<float>(rand() % 360) * 3.14159f / 180.0f;
        float speed = 60.0f + static_cast<float>(rand() % 120);
        float lifeSpan = 0.25f + static_cast<float>(rand() % 25) / 100.0f;
        particles.push_back({ x, y, cosf(angle) * speed, sinf(angle) * speed, lifeSpan, lifeSpan, col, true });
    }
}

void SaveGameData(int gold, const std::vector<Card>& deck) {
    std::ofstream file("save_game.dat", std::ios::binary);
    if (!file.is_open()) return;
    file.write(reinterpret_cast<const char*>(&gold), sizeof(gold));
    size_t deckSize = deck.size();
    file.write(reinterpret_cast<const char*>(&deckSize), sizeof(deckSize));
    for (const auto& c : deck) {
        file.write(reinterpret_cast<const char*>(&c.isGachaUnlocked), sizeof(c.isGachaUnlocked));
        file.write(reinterpret_cast<const char*>(&c.isSelectedForDeck), sizeof(c.isSelectedForDeck));
    }
    file.close();
}

void LoadGameData(int& gold, std::vector<Card>& deck) {
    std::ifstream file("save_game.dat", std::ios::binary);
    if (!file.is_open()) return;
    file.read(reinterpret_cast<char*>(&gold), sizeof(gold));
    size_t deckSize = 0;
    file.read(reinterpret_cast<char*>(&deckSize), sizeof(deckSize));
    for (size_t i = 0; i < deckSize && i < deck.size(); ++i) {
        file.read(reinterpret_cast<char*>(&deck[i].isGachaUnlocked), sizeof(deck[i].isGachaUnlocked));
        file.read(reinterpret_cast<char*>(&deck[i].isSelectedForDeck), sizeof(deck[i].isSelectedForDeck));
    }
    file.close();
}

// 主菜单法军绝境背景
void DrawFrenchSoldierDespairMenuBackground(SDL_Renderer* renderer, std::vector<MenuParticle>& menuParticles, float deltaTime, float totalTime) {
    for (int y = 0; y < static_cast<int>(VIEW_HEIGHT); ++y) {
        float ratio = static_cast<float>(y) / VIEW_HEIGHT;
        Uint8 r = static_cast<Uint8>(std::min(255.0f, 30.0f + ratio * 45.0f + sinf(totalTime * 1.5f) * 5.0f));
        Uint8 g = static_cast<Uint8>(std::min(255.0f, 20.0f + ratio * 25.0f));
        Uint8 b = static_cast<Uint8>(std::min(255.0f, 15.0f + ratio * 20.0f));
        SDL_SetRenderDrawColor(renderer, r, g, b, 255);
        SDL_RenderDrawLine(renderer, 0, y, static_cast<int>(VIEW_WIDTH), y);
    }

    if (rand() % 120 == 0) {
        SDL_SetRenderDrawColor(renderer, 255, 140, 60, 80);
        SDL_Rect flashRect = { rand() % (int)VIEW_WIDTH - 200, 100 + rand() % 200, 400, 200 };
        SDL_RenderFillRect(renderer, &flashRect);
    }

    if (menuParticles.size() < 120) {
        MenuParticle p;
        p.isSmoke = (rand() % 3 == 0);
        p.x = static_cast<float>(rand() % (int)VIEW_WIDTH);
        p.y = VIEW_HEIGHT + 20.0f;
        p.vx = -30.0f + static_cast<float>(rand() % 60);
        p.vy = -40.0f - static_cast<float>(rand() % 80);
        p.life = 0.0f;
        p.maxLife = 3.0f + static_cast<float>(rand() % 4);
        p.size = p.isSmoke ? (15.0f + rand() % 25) : (2.0f + rand() % 4);
        p.color = p.isSmoke ? SDL_Color{ 40, 35, 35, 120 } : SDL_Color{ 255, static_cast<Uint8>(100 + rand() % 100), 30, 255 };
        menuParticles.push_back(p);
    }

    for (auto& p : menuParticles) {
        p.x += p.vx * deltaTime;
        p.y += p.vy * deltaTime;
        p.life += deltaTime;

        if (p.life < p.maxLife) {
            SDL_SetRenderDrawColor(renderer, p.color.r, p.color.g, p.color.b, p.color.a);
            SDL_Rect pRect = { static_cast<int>(p.x), static_cast<int>(p.y), static_cast<int>(p.size), static_cast<int>(p.size) };
            SDL_RenderFillRect(renderer, &pRect);
        }
    }
    menuParticles.erase(std::remove_if(menuParticles.begin(), menuParticles.end(), [](const MenuParticle& p) { return p.life >= p.maxLife; }), menuParticles.end());

    SDL_SetRenderDrawColor(renderer, 15, 12, 12, 255);
    SDL_Rect ground = { 0, static_cast<int>(VIEW_HEIGHT) - 180, static_cast<int>(VIEW_WIDTH), 180 };
    SDL_RenderFillRect(renderer, &ground);

    SDL_Rect ruin1 = { 100, static_cast<int>(VIEW_HEIGHT) - 280, 80, 100 };
    SDL_Rect ruin2 = { 850, static_cast<int>(VIEW_HEIGHT) - 320, 120, 140 };
    SDL_RenderFillRect(renderer, &ruin1);
    SDL_RenderFillRect(renderer, &ruin2);

    int sx = static_cast<int>(VIEW_WIDTH * 0.72f);
    int sy = static_cast<int>(VIEW_HEIGHT) - 220;

    SDL_SetRenderDrawColor(renderer, 55, 75, 95, 255);
    SDL_Rect bodyCoat = { sx - 20, sy, 40, 70 };
    SDL_RenderFillRect(renderer, &bodyCoat);

    SDL_Rect coatLower = { sx - 24, sy + 60, 48, 50 };
    SDL_RenderFillRect(renderer, &coatLower);

    SDL_SetRenderDrawColor(renderer, 40, 35, 30, 255);
    SDL_Rect legL = { sx - 16, sy + 110, 12, 45 };
    SDL_Rect legR = { sx + 4, sy + 110, 12, 45 };
    SDL_RenderFillRect(renderer, &legL);
    SDL_RenderFillRect(renderer, &legR);

    SDL_SetRenderDrawColor(renderer, 190, 140, 110, 255);
    SDL_Rect head = { sx - 10, sy - 22, 20, 22 };
    SDL_RenderFillRect(renderer, &head);

    SDL_SetRenderDrawColor(renderer, 45, 60, 75, 255);
    SDL_Rect helmetBase = { sx - 16, sy - 28, 32, 10 };
    SDL_Rect helmetTop = { sx - 12, sy - 36, 24, 10 };
    SDL_Rect helmetCrest = { sx - 3, sy - 40, 6, 12 };
    SDL_RenderFillRect(renderer, &helmetBase);
    SDL_RenderFillRect(renderer, &helmetTop);
    SDL_RenderFillRect(renderer, &helmetCrest);

    SDL_SetRenderDrawColor(renderer, 70, 50, 30, 255);
    SDL_Rect rifleStock = { sx + 12, sy - 10, 8, 80 };
    SDL_RenderFillRect(renderer, &rifleStock);

    SDL_SetRenderDrawColor(renderer, 90, 90, 95, 255);
    SDL_Rect rifleBarrel = { sx + 14, sy - 70, 4, 60 };
    SDL_Rect bayonet = { sx + 15, sy - 100, 2, 30 };
    SDL_RenderFillRect(renderer, &rifleBarrel);
    SDL_RenderFillRect(renderer, &bayonet);

    SDL_SetRenderDrawColor(renderer, 80, 50, 25, 255);
    SDL_RenderDrawLine(renderer, sx - 18, sy + 5, sx + 18, sy + 50);
}

// 统一的精致对局单位渲染函数
void RenderDetailedGameUnit(SDL_Renderer* renderer, const Actor& u, int ux, int uy) {
    bool isTank = (u.uType >= UNIT_SHERMAN && u.uType <= UNIT_SUPER_HEAVY) || u.uType == UNIT_AA_HALFTRACK || u.uType == UNIT_MOBILE_PILLBOX;
    bool isZombie = (u.uType >= UNIT_ZOMBIE_WALKER);
    bool isTesla = (u.uType == UNIT_TESLA_MECH);

    SDL_Color coatColor = { 55, 75, 95, 255 };
    SDL_Color helmetColor = { 45, 60, 75, 255 };
    if (u.nation == NATION_GERMANY) {
        coatColor = { 60, 65, 55, 255 };
        helmetColor = { 50, 55, 45, 255 };
    }
    else if (u.nation == NATION_SOVIET) {
        coatColor = { 95, 65, 50, 255 };
        helmetColor = { 70, 55, 45, 255 };
    }
    else if (u.nation == NATION_US) {
        coatColor = { 75, 90, 65, 255 };
        helmetColor = { 65, 80, 55, 255 };
    }
    else if (u.nation == NATION_JAPAN) {
        coatColor = { 90, 85, 70, 255 };
        helmetColor = { 75, 70, 60, 255 };
    }

    if (u.flashTimer > 0) {
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    }

    bool isCharging = (u.currentOrder == ORDER_CHARGE);
    bool isDefending = (u.currentOrder == ORDER_DEFEND);

    if (isZombie) {
        int size = (u.uType == UNIT_ZOMBIE_BRUTE) ? 24 : 12;
        SDL_SetRenderDrawColor(renderer, u.uType == UNIT_ZOMBIE_RUNNER ? 200 : 70, 50, u.uType == UNIT_ZOMBIE_BRUTE ? 160 : 80, 255);
        SDL_Rect zBody = { ux - size, uy - size + (isCharging ? -3 : 0), size * 2, size * 2 };
        SDL_RenderFillRect(renderer, &zBody);
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
        SDL_Rect zEye1 = { ux - 3, uy - 3, 2, 2 };
        SDL_Rect zEye2 = { ux + 1, uy - 3, 2, 2 };
        SDL_RenderFillRect(renderer, &zEye1);
        SDL_RenderFillRect(renderer, &zEye2);
    }
    else if (isTesla || isTank) {
        SDL_SetRenderDrawColor(renderer, u.isEnemyTeam ? 140 : 45, u.isEnemyTeam ? 45 : 95, 45, 255);
        SDL_Rect trackL = { ux - 18, uy - 12, 6, 24 };
        SDL_Rect trackR = { ux + 12, uy - 12, 6, 24 };
        SDL_Rect mainHull = { ux - 14, uy - 10, 28, 20 };
        SDL_RenderFillRect(renderer, &trackL);
        SDL_RenderFillRect(renderer, &trackR);
        SDL_RenderFillRect(renderer, &mainHull);

        SDL_SetRenderDrawColor(renderer, isTesla ? 180 : (u.isEnemyTeam ? 170 : 60), isTesla ? 100 : (u.isEnemyTeam ? 60 : 120), isTesla ? 220 : 60, 255);
        SDL_Rect turret = { ux - 8, uy - 8, 16, 16 };
        SDL_RenderFillRect(renderer, &turret);

        SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
        SDL_Rect barrel = { ux - 2, uy - 20 - static_cast<int>(u.recoilOffset), 4, 14 };
        SDL_RenderFillRect(renderer, &barrel);

        if (u.recoilOffset > 2.0f) {
            SDL_SetRenderDrawColor(renderer, 255, 200, 50, 255);
            SDL_Rect muzzleFlash = { ux - 4, uy - 26, 8, 8 };
            SDL_RenderFillRect(renderer, &muzzleFlash);
        }
    }
    else {
        int leanOffset = isCharging ? -4 : (isDefending ? 2 : 0);

        SDL_SetRenderDrawColor(renderer, coatColor.r, coatColor.g, coatColor.b, 255);
        SDL_Rect bodyCoat = { ux - 6, uy - 7 + leanOffset, 12, 14 };
        SDL_RenderFillRect(renderer, &bodyCoat);

        SDL_SetRenderDrawColor(renderer, 35, 30, 25, 255);
        SDL_Rect legL = { ux - (isCharging ? 7 : 5), uy + 7, 4, 7 };
        SDL_Rect legR = { ux + (isCharging ? 3 : 1), uy + 7, 4, 7 };
        SDL_RenderFillRect(renderer, &legL);
        SDL_RenderFillRect(renderer, &legR);

        SDL_SetRenderDrawColor(renderer, 210, 160, 130, 255);
        SDL_Rect head = { ux - 3, uy - 13 + leanOffset, 6, 6 };
        SDL_RenderFillRect(renderer, &head);

        SDL_SetRenderDrawColor(renderer, helmetColor.r, helmetColor.g, helmetColor.b, 255);
        SDL_Rect helmet = { ux - 5, uy - 17 + leanOffset, 10, 5 };
        SDL_RenderFillRect(renderer, &helmet);

        bool isFiringAction = (u.recoilOffset > 0.0f);
        if (isFiringAction && u.uType != UNIT_FLAMETHROWER) {
            SDL_SetRenderDrawColor(renderer, 255, 240, 100, 255);
            SDL_Rect mFlash = { ux + 5, uy - 14, 4, 4 };
            SDL_RenderFillRect(renderer, &mFlash);
        }
    }

    if (u.isSelectedByPlayer) {
        SDL_SetRenderDrawColor(renderer, 255, 230, 0, 255);
        SDL_Rect selectBox = { ux - 14, uy - 20, 28, 28 };
        SDL_RenderDrawRect(renderer, &selectBox);
    }
}

std::vector<Card> GetNationCards(Nation nation) {
    std::vector<Card> cards;
    cards.push_back({ UNIT_INFANTRY, "Infantry", "前线步兵班", "基础作战与防御", 3, 10, 2.2f, 0.0f, {80,100,80,255}, true, true, TIER_NORMAL });
    cards.push_back({ UNIT_SCOUT, "Recon Car", "装甲侦察车", "高速机动侦察", 2, 3, 2.0f, 0.0f, {90,110,70,255}, true, true, TIER_NORMAL });
    cards.push_back({ UNIT_PIONEER, "Pioneer", "战地工兵", "构筑战地掩体", 3, 6, 2.8f, 0.0f, {90,80,60,255}, true, true, TIER_NORMAL });
    cards.push_back({ UNIT_FLAMETHROWER, "Flamethrower", "喷火突击者", "近距离范围灼烧", 4, 3, 3.2f, 0.0f, {220, 120, 50, 255 }, false, false, TIER_NORMAL });

    cards.push_back({ UNIT_AIRBORNE, "Airborne", "精锐伞兵", "突击穿插敌后", 4, 6, 3.0f, 0.0f, {100,90,70,255}, false, false, TIER_ADVANCED });
    cards.push_back({ UNIT_HMG, "HMG Team", "重机枪阵地", "持续火力压制", 4, 4, 3.0f, 0.0f, {70,90,70,255}, false, false, TIER_ADVANCED });
    cards.push_back({ UNIT_SNIPER, "Sniper Team", "精锐狙击组", "超远精准点杀", 3, 2, 3.5f, 0.0f, {120,130,90,255}, false, false, TIER_ADVANCED });
    cards.push_back({ UNIT_MORTAR, "Mortar", "重型迫击炮", "曲射范围支援", 4, 3, 3.5f, 0.0f, {80,75,65,255}, false, false, TIER_ADVANCED });
    cards.push_back({ UNIT_AT_GUN, "AT Gun", "反坦克炮", "重型反装甲", 4, 3, 3.5f, 0.0f, {70,70,70,255}, false, false, TIER_ADVANCED });
    cards.push_back({ UNIT_AA_HALFTRACK, "AA Vehicle", "防空装甲车", "高射速面杀伤", 4, 2, 3.2f, 0.0f, {110,120,80,255}, false, false, TIER_ADVANCED });
    cards.push_back({ UNIT_SHERMAN, "Medium Tank", "主力中型坦克", "装甲突击集群", 5, 2, 4.2f, 0.0f, {95,110,75,255}, false, false, TIER_ADVANCED });
    cards.push_back({ UNIT_MOBILE_PILLBOX, "Mobile Pillbox", "移动堡垒", "阵地固守核心", 5, 1, 4.5f, 0.0f, {100,100,110,255}, false, false, TIER_ADVANCED });

    cards.push_back({ UNIT_TANK_DESTROYER, "Tank Hunter", "坦克歼击车", "远程装甲狙击", 5, 2, 4.0f, 0.0f, {85,95,75,255}, false, false, TIER_LEGENDARY });
    cards.push_back({ UNIT_HEAVY_TANK, "Heavy Tank", "重型突破坦克", "钢铁战线推进", 7, 1, 5.5f, 0.0f, {100,120,80,255}, false, false, TIER_LEGENDARY });
    cards.push_back({ UNIT_ARTILLERY, "SPG Artillery", "自行火炮", "远程饱和轰炸", 6, 1, 6.0f, 0.0f, {60,80,80,255}, false, false, TIER_LEGENDARY });
    cards.push_back({ UNIT_SUPER_HEAVY, "Super Heavy", "超重型巨兽坦克", "战场终结堡垒", 9, 1, 7.5f, 0.0f, {70,80,90,255}, false, false, TIER_LEGENDARY });
    cards.push_back({ UNIT_TESLA_MECH, "Tesla Mech", "磁能机甲", "超能电击集群", 6, 1, 6.5f, 0.0f, {150, 80, 220, 255 }, false, false, TIER_LEGENDARY });

    return cards;
}

void SetupUnitStats(Actor& u, UnitType type, Nation nation) {
    u.uType = type;
    u.nation = nation;
    Faction f = GetNationFaction(nation);

    float baseSpeed = 100.0f;
    int baseHp = 100;
    int baseAtk = 20;
    int baseDef = 5;
    float bodyRadius = 13.0f;

    float attackRange = 210.0f;
    float fRate = 0.45f;
    int clip = 8;
    float rTime = 2.0f;

    switch (type) {
    case UNIT_SCOUT:
        baseSpeed = 160.0f; baseHp = 70; baseAtk = 14; baseDef = 3; bodyRadius = 15.0f;
        attackRange = 190.0f; fRate = 0.25f; clip = 15; rTime = 1.8f; break;
    case UNIT_INFANTRY:
        baseSpeed = 110.0f; baseHp = 110; baseAtk = 20; baseDef = 5; bodyRadius = 12.0f;
        attackRange = 210.0f; fRate = 0.40f; clip = 8; rTime = 1.8f; break;
    case UNIT_AIRBORNE:
        baseSpeed = 120.0f; baseHp = 140; baseAtk = 28; baseDef = 8; bodyRadius = 12.0f;
        attackRange = 220.0f; fRate = 0.30f; clip = 12; rTime = 2.0f; break;
    case UNIT_PIONEER:
        baseSpeed = 110.0f; baseHp = 180; baseAtk = 32; baseDef = 12; bodyRadius = 12.0f;
        attackRange = 75.0f; fRate = 0.60f; clip = 6; rTime = 2.2f; break;
    case UNIT_FLAMETHROWER:
        baseSpeed = 115.0f; baseHp = 160; baseAtk = 45; baseDef = 10; bodyRadius = 13.0f;
        attackRange = 140.0f; fRate = 0.10f; clip = 30; rTime = 3.0f; break;
    case UNIT_AA_HALFTRACK:
        baseSpeed = 140.0f; baseHp = 220; baseAtk = 38; baseDef = 10; bodyRadius = 18.0f;
        attackRange = 270.0f; fRate = 0.15f; clip = 30; rTime = 3.5f; break;
    case UNIT_HMG:
        baseSpeed = 75.0f; baseHp = 120; baseAtk = 35; baseDef = 7; bodyRadius = 13.0f;
        attackRange = 300.0f; fRate = 0.12f; clip = 50; rTime = 4.2f; break;
    case UNIT_SHERMAN:
        baseSpeed = 135.0f; baseHp = 380; baseAtk = 40; baseDef = 20; bodyRadius = 22.0f;
        attackRange = 220.0f; fRate = 1.50f; clip = 5; rTime = 3.2f; break;
    case UNIT_MOBILE_PILLBOX:
        baseSpeed = 45.0f; baseHp = 650; baseAtk = 50; baseDef = 35; bodyRadius = 24.0f;
        attackRange = 260.0f; fRate = 0.20f; clip = 40; rTime = 4.5f; break;
    case UNIT_HEAVY_TANK:
        baseSpeed = 110.0f; baseHp = 550; baseAtk = 55; baseDef = 28; bodyRadius = 25.0f;
        attackRange = 240.0f; fRate = 2.20f; clip = 4; rTime = 4.0f; break;
    case UNIT_TANK_DESTROYER:
        baseSpeed = 130.0f; baseHp = 340; baseAtk = 55; baseDef = 16; bodyRadius = 22.0f;
        attackRange = 320.0f; fRate = 1.80f; clip = 4; rTime = 3.5f; break;
    case UNIT_SUPER_HEAVY:
        baseSpeed = 50.0f; baseHp = 850; baseAtk = 85; baseDef = 40; bodyRadius = 28.0f;
        attackRange = 320.0f; fRate = 2.50f; clip = 3; rTime = 4.5f; break;
    case UNIT_MORTAR:
        baseSpeed = 70.0f; baseHp = 90; baseAtk = 42; baseDef = 4; bodyRadius = 13.0f;
        attackRange = 380.0f; fRate = 1.80f; clip = 4; rTime = 3.8f; break;
    case UNIT_AT_GUN:
        baseSpeed = 70.0f; baseHp = 120; baseAtk = 60; baseDef = 6; bodyRadius = 16.0f;
        attackRange = 400.0f; fRate = 2.00f; clip = 3; rTime = 3.5f; break;
    case UNIT_SNIPER:
        baseSpeed = 115.0f; baseHp = 65; baseAtk = 85; baseDef = 2; bodyRadius = 11.0f;
        attackRange = 480.0f; fRate = 1.20f; clip = 5; rTime = 2.8f; break;
    case UNIT_ARTILLERY:
        baseSpeed = 60.0f; baseHp = 320; baseAtk = 75; baseDef = 12; bodyRadius = 24.0f;
        attackRange = 520.0f; fRate = 3.00f; clip = 2; rTime = 5.0f; break;
    case UNIT_TESLA_MECH:
        baseSpeed = 95.0f; baseHp = 600; baseAtk = 70; baseDef = 32; bodyRadius = 26.0f;
        attackRange = 250.0f; fRate = 0.80f; clip = 10; rTime = 2.5f; break;
    case UNIT_ZOMBIE_WALKER:
        baseSpeed = 85.0f; baseHp = 140; baseAtk = 18; baseDef = 2; bodyRadius = 12.0f;
        attackRange = 35.0f; fRate = 0.80f; clip = 999; rTime = 0.0f; break;
    case UNIT_ZOMBIE_RUNNER:
        baseSpeed = 175.0f; baseHp = 90; baseAtk = 25; baseDef = 1; bodyRadius = 11.0f;
        attackRange = 35.0f; fRate = 0.60f; clip = 999; rTime = 0.0f; break;
    case UNIT_ZOMBIE_BRUTE:
        baseSpeed = 70.0f; baseHp = 1200; baseAtk = 65; baseDef = 18; bodyRadius = 27.0f;
        attackRange = 45.0f; fRate = 1.00f; clip = 999; rTime = 0.0f; break;
    }

    if (f == FACTION_AXIS) {
        u.hp = u.maxHp = static_cast<int>(baseHp * 1.15f);
        u.attack = static_cast<int>(baseAtk * 1.10f);
        u.defense = static_cast<int>(baseDef * 1.15f);
        u.speed = baseSpeed * 0.98f;
    }
    else {
        u.hp = u.maxHp = baseHp;
        u.attack = baseAtk;
        u.defense = baseDef;
        u.speed = baseSpeed * 1.05f;
    }

    u.attackRange = attackRange;
    u.fireRate = fRate;
    u.maxClipAmmo = clip;
    u.currentClipAmmo = clip;
    u.reloadTimeMax = rTime;
    u.isReloading = false;
    u.currentReloadTimer = 0.0f;
    u.suppressionValue = 0.0f;

    u.radius = bodyRadius;
    u.currentOrder = ORDER_ADVANCE;
}

// ==========================================
// 4. 主程序入口
// ==========================================
int main(int argc, char* argv[]) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) return -1;

    GameState gameState = STATE_MENU_SELECT;
    GameMode gameMode = MODE_1V1;
    Nation playerNation = NATION_FRANCE;
    Nation enemyNation = NATION_GERMANY;

    int playerGold = 25;
    std::vector<Card> playerDeck = GetNationCards(playerNation);

    LoadGameData(playerGold, playerDeck);

    std::string gachaResultMsg = "✨ 战术军需处已开启：稀有王牌需凭战功抽取！";

    int currentZombieWave = 1;
    const int maxZombieWaves = 10;
    float waveSpawnIntervalTimer = 0.0f;
    int zombiesRemainingInWave = 0;
    bool waveInProgress = false;

    bool commandAllUnitsMode = true;
    std::vector<MenuParticle> menuParticles;
    float globalTotalTime = 0.0f;
    bool showTacticalMenuDrawer = false;
    bool isGameFullscreen = false;

    SDL_Window* window = SDL_CreateWindow(
        "WW2 Frontline Command - Airwalls & Tactical Victory Rules",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        static_cast<int>(VIEW_WIDTH), static_cast<int>(VIEW_HEIGHT),
        SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
    );
    if (!window) { SDL_Quit(); return -1; }

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!renderer) {
        renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    }
    if (!renderer) { SDL_DestroyWindow(window); SDL_Quit(); return -1; }

    SDL_RenderSetLogicalSize(renderer, static_cast<int>(VIEW_WIDTH), static_cast<int>(VIEW_HEIGHT));

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGui::StyleColorsDark();

    ImFontConfig font_cfg;
    font_cfg.Flags |= ImFontFlags_NoLoadError;
    ImFont* chineseFont = io.Fonts->AddFontFromFileTTF("simhei.ttf", 18.0f, &font_cfg, io.Fonts->GetGlyphRangesChineseFull());
    if (!chineseFont) {
        chineseFont = io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/simhei.ttf", 18.0f, &font_cfg, io.Fonts->GetGlyphRangesChineseFull());
    }
    if (!chineseFont) {
        io.Fonts->AddFontDefault();
    }

    ImGui_ImplSDL2_InitForSDLRenderer(window, renderer);
    ImGui_ImplSDLRenderer2_Init(renderer);

    Camera cam;
    cam.x = MAP_WIDTH / 2.0f;
    cam.y = MAP_HEIGHT - 900.0f;

    std::vector<River> rivers = { { 0.0f, MAP_HEIGHT / 2.0f - 80.0f, MAP_WIDTH, 160.0f } };
    std::vector<Bridge> bridges = {
        { 900.0f, MAP_HEIGHT / 2.0f - 90.0f, 240.0f, 180.0f },
        { 1800.0f, MAP_HEIGHT / 2.0f - 90.0f, 240.0f, 180.0f },
        { 2700.0f, MAP_HEIGHT / 2.0f - 90.0f, 240.0f, 180.0f }
    };

    std::vector<CapturePoint> capPoints = {
        { "阿尔法前线据点 (Alpha)", 900.0f, MAP_HEIGHT / 2.0f, 200.0f, -1, NATION_US, 0.0f, false },
        { "中央战略枢纽 (Bravo HQ)", 1800.0f, MAP_HEIGHT / 2.0f, 220.0f, -1, NATION_US, 0.0f, true },
        { "查理前线据点 (Charlie)", 2700.0f, MAP_HEIGHT / 2.0f, 200.0f, -1, NATION_US, 0.0f, false }
    };

    float playerSupply = 6.0f;
    const float maxSupply = 10.0f;
    int selectedCardIndex = -1;
    CommandSkillType activeSkill = SKILL_NONE;

    CapitolHQ playerHQ = { MAP_WIDTH / 2.0f, MAP_HEIGHT - 160.0f, 4000, 4000, false };
    CapitolHQ enemyHQ = { MAP_WIDTH / 2.0f, 160.0f, 4000, 4000, true };

    std::vector<Actor> units;
    std::vector<Bullet> bullets;
    std::vector<Fortification> fortifications;
    std::vector<SmokeArea> smokeAreas;
    std::vector<ImpactParticle> impactParticles;

    float aiSpawnTimer = 4.5f;
    float allyAiSpawnTimer = 5.0f;
    bool gameOver = false;
    std::string winMessage = "";

    bool isRightMouseDragging = false;
    float rightMouseClickStartX = 0.0f, rightMouseClickStartY = 0.0f;

    bool quit = false;
    SDL_Event e;
    Uint32 lastTime = SDL_GetTicks();

    while (!quit) {
        while (SDL_PollEvent(&e) != 0) {
            ImGui_ImplSDL2_ProcessEvent(&e);

            if (e.type == SDL_QUIT) {
                quit = true;
            }
            else if (e.type == SDL_WINDOWEVENT) {
                if (e.window.event == SDL_WINDOWEVENT_RESIZED || e.window.event == SDL_WINDOWEVENT_SIZE_CHANGED) {
                    SDL_RenderSetLogicalSize(renderer, static_cast<int>(VIEW_WIDTH), static_cast<int>(VIEW_HEIGHT));
                }
            }
            else if (e.type == SDL_MOUSEBUTTONDOWN) {
                if (e.button.button == SDL_BUTTON_RIGHT) {
                    isRightMouseDragging = true;
                    int rawMx, rawMy;
                    SDL_GetMouseState(&rawMx, &rawMy);
                    rightMouseClickStartX = static_cast<float>(rawMx);
                    rightMouseClickStartY = static_cast<float>(rawMy);
                }
            }
            else if (e.type == SDL_MOUSEBUTTONUP) {
                if (e.button.button == SDL_BUTTON_RIGHT) {
                    isRightMouseDragging = false;
                    int rawMx, rawMy;
                    SDL_GetMouseState(&rawMx, &rawMy);

                    float moveDist = sqrtf(powf(rawMx - rightMouseClickStartX, 2) + powf(rawMy - rightMouseClickStartY, 2));
                    if (moveDist < 8.0f && gameState == STATE_PLAYING && !gameOver && !io.WantCaptureMouse) {
                        float logicalX = 0.0f, logicalY = 0.0f;
                        SDL_RenderWindowToLogical(renderer, rawMx, rawMy, &logicalX, &logicalY);
                        if (logicalY < 710.0f) {
                            float targetWorldX = (logicalX - VIEW_WIDTH / 2.0f) + cam.x;
                            float targetWorldY = (logicalY - VIEW_HEIGHT / 2.0f) + cam.y;

                            // 空气墙校验：点击位置越界则不移动
                            if (!IsInAirWallBoundary(targetWorldX, targetWorldY)) {
                                for (auto& u : units) {
                                    if (!u.isEnemyTeam && (commandAllUnitsMode || u.isSelectedByPlayer)) {
                                        u.currentOrder = ORDER_MOVE_TO;
                                        u.targetDestX = targetWorldX;
                                        u.targetDestY = targetWorldY;
                                        u.hasCustomTarget = true;
                                    }
                                }
                                SpawnImpactSparks(impactParticles, targetWorldX, targetWorldY, 12, { 0, 255, 255, 255 });
                            }
                        }
                    }
                }
            }
            else if (e.type == SDL_MOUSEMOTION && isRightMouseDragging) {
                cam.x -= static_cast<float>(e.motion.xrel);
                cam.y -= static_cast<float>(e.motion.yrel);
            }
        }

        Uint32 currentTime = SDL_GetTicks();
        float deltaTime = static_cast<float>(currentTime - lastTime) / 1000.0f;
        lastTime = currentTime;
        globalTotalTime += deltaTime;

        if (gameState == STATE_PLAYING && !gameOver) {
            Uint32 mouseState = SDL_GetMouseState(nullptr, nullptr);
            static bool leftWasPressed = false;
            bool leftIsPressed = (mouseState & SDL_BUTTON(SDL_BUTTON_LEFT)) != 0;

            if (leftIsPressed && !leftWasPressed) {
                if (!io.WantCaptureMouse) {
                    int rawMx, rawMy;
                    SDL_GetMouseState(&rawMx, &rawMy);

                    float logicalX = 0.0f, logicalY = 0.0f;
                    SDL_RenderWindowToLogical(renderer, rawMx, rawMy, &logicalX, &logicalY);

                    if (logicalY < 710.0f) {
                        float worldX = (logicalX - VIEW_WIDTH / 2.0f) + cam.x;
                        float worldY = (logicalY - VIEW_HEIGHT / 2.0f) + cam.y;

                        if (!IsInAirWallBoundary(worldX, worldY)) {
                            if (activeSkill == SKILL_AIRSTRIKE && playerSupply >= 5.0f) {
                                playerSupply -= 5.0f;
                                activeSkill = SKILL_NONE;
                                PlaySoundEffect("airstrike");
                                cam.shakeTimer = 0.6f;
                                cam.shakeIntensity = 15.0f;
                                SpawnImpactSparks(impactParticles, worldX, worldY, 50, { 255, 120, 50, 255 });

                                for (auto& u : units) {
                                    if (u.isEnemyTeam && !u.isDead) {
                                        float dst = sqrtf(powf(u.x - worldX, 2) + powf(u.y - worldY, 2));
                                        if (dst <= 280.0f) {
                                            u.hp -= 350;
                                            u.flashTimer = 0.2f;
                                        }
                                    }
                                }
                            }
                            else if (activeSkill == SKILL_SMOKE_SCREEN && playerSupply >= 3.0f) {
                                playerSupply -= 3.0f;
                                activeSkill = SKILL_NONE;
                                smokeAreas.push_back({ worldX, worldY, 220.0f, 12.0f, true });
                                PlaySoundEffect("click");
                            }
                            else if (selectedCardIndex != -1) {
                                Card& chosenCard = playerDeck[selectedCardIndex];
                                int finalCost = chosenCard.supplyCost;

                                if (playerSupply >= static_cast<float>(finalCost)) {
                                    playerSupply -= static_cast<float>(finalCost);
                                    chosenCard.currentCooldown = chosenCard.cooldownMax;
                                    PlaySoundEffect("deploy");
                                    SpawnImpactSparks(impactParticles, worldX, worldY, 25, { 100, 255, 100, 255 });

                                    for (int k = 0; k < chosenCard.spawnCount; ++k) {
                                        float colOffset = static_cast<float>(k % 4) * 32.0f - 48.0f;
                                        float rowOffset = static_cast<float>(k / 4) * 22.0f;
                                        float fx = worldX + colOffset;
                                        float fy = worldY + rowOffset;

                                        Actor u;
                                        u.x = fx; u.y = fy; u.isEnemyTeam = false; u.isAllyAI = false;
                                        SetupUnitStats(u, chosenCard.uType, playerNation);
                                        units.push_back(u);
                                    }
                                    selectedCardIndex = -1;
                                }
                            }
                            else {
                                for (auto& u : units) {
                                    if (!u.isEnemyTeam && !u.isAllyAI) {
                                        float dist = sqrtf(powf(u.x - worldX, 2) + powf(u.y - worldY, 2));
                                        if (dist < 32.0f) {
                                            u.isSelectedByPlayer = !u.isSelectedByPlayer;
                                            PlaySoundEffect("click");
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            leftWasPressed = leftIsPressed;
        }

        if (cam.shakeTimer > 0) {
            cam.shakeTimer -= deltaTime;
            if (cam.shakeIntensity <= 0) cam.shakeIntensity = 0;
        }

        if (gameState == STATE_PLAYING) {
            cam.x = std::max(VIEW_WIDTH / 2.0f, std::min(MAP_WIDTH - VIEW_WIDTH / 2.0f, cam.x));
            cam.y = std::max(VIEW_HEIGHT / 2.0f, std::min(MAP_HEIGHT - VIEW_HEIGHT / 2.0f, cam.y));
        }

        if (gameState == STATE_PLAYING && !gameOver) {
            int playerControlledPoints = 0;

            for (auto& sm : smokeAreas) {
                if (sm.active) {
                    sm.life -= deltaTime;
                    if (sm.life <= 0.0f) sm.active = false;
                }
            }

            for (auto& p : impactParticles) {
                if (!p.active) continue;
                p.x += p.vx * deltaTime;
                p.y += p.vy * deltaTime;
                p.life -= deltaTime;
                if (p.life <= 0) p.active = false;
            }
            impactParticles.erase(std::remove_if(impactParticles.begin(), impactParticles.end(), [](const ImpactParticle& p) { return !p.active; }), impactParticles.end());

            for (size_t i = 0; i < capPoints.size(); ++i) {
                auto& cp = capPoints[i];
                int alliesInArea = 0, enemiesInArea = 0;
                for (const auto& u : units) {
                    if (u.isDead) continue;
                    float dst = sqrtf(powf(u.x - cp.x, 2) + powf(u.y - cp.y, 2));
                    if (dst <= cp.radius) {
                        if (u.isEnemyTeam) enemiesInArea++;
                        else alliesInArea++;
                    }
                }

                if (alliesInArea > 0 && enemiesInArea == 0) {
                    if (cp.owner != 0) {
                        cp.captureProgress += 30.0f * deltaTime;
                        if (cp.captureProgress >= 100.0f) {
                            cp.captureProgress = 100.0f;
                            cp.owner = 0;
                            cp.ownerNation = playerNation;
                        }
                    }
                }
                else if (enemiesInArea > 0 && alliesInArea == 0) {
                    if (cp.owner != 1) {
                        cp.captureProgress -= 30.0f * deltaTime;
                        if (cp.captureProgress <= -100.0f) {
                            cp.captureProgress = -100.0f;
                            cp.owner = 1;
                            cp.ownerNation = enemyNation;
                        }
                    }
                }

                if (cp.owner == 0) playerControlledPoints++;
            }

            // 占领据点可提供额外的战地物资回复加成
            float baseRegen = 0.60f + static_cast<float>(playerControlledPoints) * 0.45f;
            playerSupply += baseRegen * deltaTime;
            if (playerSupply > maxSupply) playerSupply = maxSupply;

            for (auto& card : playerDeck) {
                if (card.currentCooldown > 0) {
                    card.currentCooldown -= deltaTime;
                    if (card.currentCooldown < 0) card.currentCooldown = 0;
                }
            }

            if (gameMode == MODE_ZOMBIE_STAND) {
                int liveZombiesCount = 0;
                for (const auto& u : units) {
                    if (u.isEnemyTeam && !u.isDead) liveZombiesCount++;
                }

                if (!waveInProgress) {
                    if (currentZombieWave <= maxZombieWaves) {
                        zombiesRemainingInWave = 6 + currentZombieWave * 5;
                        waveInProgress = true;
                    }
                    else {
                        gameOver = true;
                        playerGold += 25;
                        winMessage = "【坚守成功】成功抵御 10 波丧尸狂潮！获得 25 金币奖励！(VICTORY)";
                        SaveGameData(playerGold, playerDeck);
                    }
                }
                else {
                    waveSpawnIntervalTimer -= deltaTime;
                    if (waveSpawnIntervalTimer <= 0 && zombiesRemainingInWave > 0) {
                        waveSpawnIntervalTimer = 1.2f;
                        zombiesRemainingInWave--;

                        UnitType zType = UNIT_ZOMBIE_WALKER;
                        int randVal = rand() % 100;
                        if (currentZombieWave >= 4 && randVal < 35) zType = UNIT_ZOMBIE_RUNNER;
                        if (currentZombieWave >= 7 && randVal < 15) zType = UNIT_ZOMBIE_BRUTE;

                        Actor zUnit;
                        zUnit.x = 400.0f + static_cast<float>(rand() % 2800);
                        zUnit.y = 100.0f + static_cast<float>(rand() % 100);
                        zUnit.isEnemyTeam = true;
                        zUnit.isAllyAI = false;
                        SetupUnitStats(zUnit, zType, NATION_ZOMBIE_HORDE);
                        units.push_back(zUnit);
                    }

                    if (zombiesRemainingInWave <= 0 && liveZombiesCount == 0) {
                        currentZombieWave++;
                        waveSpawnIntervalTimer = 3.0f;
                        waveInProgress = false;
                    }
                }
            }
            else {
                aiSpawnTimer -= deltaTime;
                if (aiSpawnTimer <= 0) {
                    aiSpawnTimer = 4.0f + static_cast<float>(rand() % 3);
                    std::vector<Card> enemyActiveCards = GetNationCards(enemyNation);
                    if (!enemyActiveCards.empty()) {
                        Card& aiCard = enemyActiveCards[rand() % enemyActiveCards.size()];
                        for (int c = 0; c < aiCard.spawnCount; ++c) {
                            float colOffset = static_cast<float>(c % 4) * 32.0f - 48.0f;
                            float rowOffset = static_cast<float>(c / 4) * 22.0f;
                            float aiStartX = 1200.0f + static_cast<float>(rand() % 1200);
                            float aiSy = 280.0f + rowOffset;

                            Actor aiUnit;
                            aiUnit.x = aiStartX + colOffset;
                            aiUnit.y = aiSy;
                            aiUnit.isEnemyTeam = true;
                            aiUnit.isAllyAI = false;
                            SetupUnitStats(aiUnit, aiCard.uType, enemyNation);
                            units.push_back(aiUnit);
                        }
                    }
                }
            }

            if (gameMode == MODE_2V2) {
                allyAiSpawnTimer -= deltaTime;
                if (allyAiSpawnTimer <= 0) {
                    allyAiSpawnTimer = 4.5f;
                    Actor allyUnit;
                    allyUnit.x = 400.0f + static_cast<float>(rand() % 400);
                    allyUnit.y = MAP_HEIGHT - 300.0f;
                    allyUnit.isEnemyTeam = false;
                    allyUnit.isAllyAI = true;
                    SetupUnitStats(allyUnit, UNIT_INFANTRY, NATION_SOVIET);
                    units.push_back(allyUnit);
                }
            }

            for (auto& bl : bullets) {
                if (!bl.active) continue;
                bl.x += bl.vx * deltaTime;
                bl.y += bl.vy * deltaTime;
                bl.life -= deltaTime;
                if (bl.life <= 0) bl.active = false;

                for (const auto& sm : smokeAreas) {
                    if (sm.active) {
                        float sDist = sqrtf(powf(bl.x - sm.x, 2) + powf(bl.y - sm.y, 2));
                        if (sDist <= sm.radius) {
                            bl.active = false;
                            break;
                        }
                    }
                }
                if (!bl.active) continue;

                for (auto& fort : fortifications) {
                    if (fort.active && fort.isEnemyTeam != bl.isEnemyTeam) {
                        float fDist = sqrtf(powf(bl.x - fort.x, 2) + powf(bl.y - fort.y, 2));
                        if (fDist < 25.0f) {
                            fort.hp -= bl.damage;
                            fort.flashTimer = 0.15f;
                            bl.active = false;
                            SpawnImpactSparks(impactParticles, bl.x, bl.y, 6, { 255, 200, 100, 255 });
                            if (fort.hp <= 0) fort.active = false;
                            break;
                        }
                    }
                }
                if (!bl.active) continue;

                for (auto& u : units) {
                    if (!u.isDead && u.isEnemyTeam != bl.isEnemyTeam) {
                        float hitDist = sqrtf(powf(bl.x - u.x, 2) + powf(bl.y - u.y, 2));
                        if (hitDist <= u.radius + 4.0f) {
                            u.hp -= std::max(4, bl.damage - u.defense);
                            u.flashTimer = 0.18f;
                            u.suppressionValue += 15.0f;
                            bl.active = false;
                            SpawnImpactSparks(impactParticles, u.x, u.y, 8, { 255, 60, 40, 255 });
                            break;
                        }
                    }
                }

                if (playerHQ.hp > 0 && bl.isEnemyTeam) {
                    float hitDist = sqrtf(powf(bl.x - playerHQ.x, 2) + powf(bl.y - playerHQ.y, 2));
                    if (hitDist < 45.0f) {
                        playerHQ.hp -= std::max(5, bl.damage - 12);
                        playerHQ.flashTimer = 0.15f;
                        bl.active = false;
                        SpawnImpactSparks(impactParticles, bl.x, bl.y, 10, { 255, 100, 100, 255 });
                    }
                }
                if (enemyHQ.hp > 0 && !bl.isEnemyTeam) {
                    float hitDist = sqrtf(powf(bl.x - enemyHQ.x, 2) + powf(enemyHQ.y - bl.y, 2));
                    if (hitDist < 45.0f) {
                        enemyHQ.hp -= std::max(5, bl.damage - 12);
                        enemyHQ.flashTimer = 0.15f;
                        bl.active = false;
                        SpawnImpactSparks(impactParticles, bl.x, bl.y, 10, { 100, 200, 255, 255 });
                    }
                }
            }

            fortifications.erase(std::remove_if(fortifications.begin(), fortifications.end(), [](const Fortification& f) { return !f.active; }), fortifications.end());
            smokeAreas.erase(std::remove_if(smokeAreas.begin(), smokeAreas.end(), [](const SmokeArea& sm) { return !sm.active; }), smokeAreas.end());

            for (auto& u : units) {
                if (u.isDead) {
                    u.deathTimer += deltaTime;
                    continue;
                }

                if (u.attackCooldown > 0) u.attackCooldown -= deltaTime;
                if (u.skillCooldown > 0) u.skillCooldown -= deltaTime;
                if (u.flashTimer > 0) u.flashTimer -= deltaTime;
                if (u.recoilOffset > 0) u.recoilOffset -= deltaTime * 30.0f;

                if (u.suppressionValue > 0) {
                    u.suppressionValue -= 8.0f * deltaTime;
                    if (u.suppressionValue < 0) u.suppressionValue = 0;
                }

                if (u.isReloading) {
                    u.currentReloadTimer -= deltaTime;
                    if (u.currentReloadTimer <= 0.0f) {
                        u.isReloading = false;
                        u.currentClipAmmo = u.maxClipAmmo;
                    }
                }

                auto MoveToTarget = [&](float targetX, float targetY) {
                    float dx = targetX - u.x;
                    float dy = targetY - u.y;
                    float len = sqrtf(dx * dx + dy * dy);
                    if (len <= 4.0f) return;

                    float moveStep = u.speed;
                    if (u.currentOrder == ORDER_CHARGE) moveStep *= 1.45f;
                    if (u.suppressionValue > 60.0f) moveStep *= 0.5f;

                    float nx = u.x + (dx / len) * moveStep * deltaTime;
                    float ny = u.y + (dy / len) * moveStep * deltaTime;

                    // 强力空气墙约束：超出地图边界则直接拦截位移
                    if (IsInAirWallBoundary(nx, ny)) return;

                    if (IsInRiverWater(nx, ny, rivers, bridges)) {
                        float bridgeTargetX = (u.x < MAP_WIDTH / 3.0f) ? 900.0f : ((u.x < MAP_WIDTH * 2.0f / 3.0f) ? 1800.0f : 2700.0f);
                        float bdx = bridgeTargetX - u.x;
                        float bdy = (targetY > u.y ? MAP_HEIGHT / 2.0f + 90.0f : MAP_HEIGHT / 2.0f - 90.0f) - u.y;
                        float blen = sqrtf(bdx * bdx + bdy * bdy);
                        if (blen > 1.0f) {
                            float px = u.x + (bdx / blen) * moveStep * deltaTime;
                            float py = u.y + (bdy / blen) * moveStep * deltaTime;
                            if (!IsInAirWallBoundary(px, py)) { u.x = px; u.y = py; }
                        }
                    }
                    else {
                        u.x = nx; u.y = ny;
                    }
                    };

                // 阵型排挤防重叠
                for (auto& other : units) {
                    if (&u != &other && !other.isDead) {
                        float cx = u.x - other.x;
                        float cy = u.y - other.y;
                        float cDist = sqrtf(cx * cx + cy * cy);
                        float minDist = u.radius + other.radius + 4.0f;
                        if (cDist < minDist && cDist > 0.001f) {
                            float pushOverlap = (minDist - cDist) * 0.4f;
                            u.x += (cx / cDist) * pushOverlap;
                            u.y += (cy / cDist) * pushOverlap;
                        }
                    }
                }

                Actor* nearbyEnemy = nullptr;
                float effectiveRange = u.attackRange;
                if (u.currentOrder == ORDER_CHARGE) effectiveRange = 55.0f;

                float minEnemyDist = effectiveRange;
                for (auto& other : units) {
                    if (!other.isDead && other.isEnemyTeam != u.isEnemyTeam) {
                        float dst = sqrtf(powf(u.x - other.x, 2) + powf(u.y - other.y, 2));
                        if (dst < minEnemyDist) { minEnemyDist = dst; nearbyEnemy = &other; }
                    }
                }

                if (nearbyEnemy) {
                    if (!u.isReloading && u.attackCooldown <= 0.0f) {
                        float bdx = nearbyEnemy->x - u.x;
                        float bdy = nearbyEnemy->y - u.y;
                        float blen = sqrtf(bdx * bdx + bdy * bdy);

                        int finalAtkDamage = u.attack;
                        if (u.currentOrder == ORDER_CHARGE) finalAtkDamage = static_cast<int>(finalAtkDamage * 1.8f);

                        if (blen > 0) {
                            bullets.push_back({ u.x, u.y, (bdx / blen) * 650.0f, (bdy / blen) * 650.0f, finalAtkDamage, u.isEnemyTeam, 1.2f, true });
                            u.recoilOffset = 6.0f;

                            u.currentClipAmmo--;
                            u.attackCooldown = u.fireRate;

                            if (u.currentClipAmmo <= 0 && u.maxClipAmmo < 900) {
                                u.isReloading = true;
                                u.currentReloadTimer = u.reloadTimeMax;
                            }
                        }
                    }
                }
                else {
                    if (u.currentOrder == ORDER_MOVE_TO && u.hasCustomTarget) {
                        MoveToTarget(u.targetDestX, u.targetDestY);
                    }
                    else if (u.currentOrder == ORDER_DEFEND) {
                    }
                    else if (u.currentOrder == ORDER_CAPTURE && !capPoints.empty()) {
                        float closestDist = 99999.0f;
                        float tx = u.x, ty = u.isEnemyTeam ? 0.0f : MAP_HEIGHT;
                        int targetOwnerVal = u.isEnemyTeam ? 1 : 0;
                        for (const auto& cp : capPoints) {
                            if (cp.owner != targetOwnerVal) {
                                float dst = sqrtf(powf(u.x - cp.x, 2) + powf(u.y - cp.y, 2));
                                if (dst < closestDist) { closestDist = dst; tx = cp.x; ty = cp.y; }
                            }
                        }
                        MoveToTarget(tx, ty);
                    }
                    else {
                        MoveToTarget(MAP_WIDTH / 2.0f, u.isEnemyTeam ? MAP_HEIGHT : 0.0f);
                    }
                }

                if (u.hp <= 0) {
                    u.isDead = true;
                    u.deathTimer = 0.0f;
                    SpawnImpactSparks(impactParticles, u.x, u.y, 15, { 150, 150, 150, 255 });
                }
            }

            units.erase(std::remove_if(units.begin(), units.end(), [](const Actor& a) { return a.isDead && a.deathTimer > 3.0f; }), units.end());
            bullets.erase(std::remove_if(bullets.begin(), bullets.end(), [](const Bullet& bl) { return !bl.active; }), bullets.end());

            // 胜负判定条件（给游戏赋予真正的意义）
            if (playerHQ.hp <= 0) {
                gameOver = true;
                winMessage = "【战役惨败】您的首都大本营已被敌军摧毁！(DEFEAT)";
                SaveGameData(playerGold, playerDeck);
            }
            if (enemyHQ.hp <= 0 && gameMode != MODE_ZOMBIE_STAND) {
                gameOver = true;
                playerGold += 20;
                winMessage = "【大获全胜】敌军指挥部已被彻底攻陷！获得 20 金币战功奖励！(VICTORY)";
                SaveGameData(playerGold, playerDeck);
            }
        }

        SDL_SetRenderDrawColor(renderer, 20, 20, 20, 255);
        SDL_RenderClear(renderer);

        if (gameState == STATE_MENU_SELECT) {
            DrawFrenchSoldierDespairMenuBackground(renderer, menuParticles, deltaTime, globalTotalTime);
        }

        ImGui_ImplSDLRenderer2_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        ImGui::NewFrame();

        int winW = 0, winH = 0;
        SDL_GetWindowSize(window, &winW, &winH);
        float currentWinW = static_cast<float>(winW);
        float currentWinH = static_cast<float>(winH);

        if (gameState == STATE_MENU_SELECT) {
            ImGui::SetNextWindowPos(ImVec2(50.0f, currentWinH * 0.22f), ImGuiCond_Always);
            ImGui::SetNextWindowSize(ImVec2(340.0f, 360.0f), ImGuiCond_Always);
            ImGui::Begin("🛡️ 前线总指挥部 (HQ)", nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove);

            ImGui::TextColored(ImVec4(1.0f, 0.85f, 0.3f, 1.0f), "⭐ 战地金币储备: %d", playerGold);
            ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "存档状态: 已自动保存到本地");
            ImGui::Separator();
            ImGui::Spacing();

            if (ImGui::Button("⚔️ 开启战术部署中心", ImVec2(300.0f, 55.0f))) {
                PlaySoundEffect("click");
                showTacticalMenuDrawer = !showTacticalMenuDrawer;
            }

            ImGui::Spacing();

            std::string fsBtnLabel = isGameFullscreen ? "🖥️ 切换窗口模式" : "🔲 切换全屏模式";
            if (ImGui::Button(fsBtnLabel.c_str(), ImVec2(300.0f, 40.0f))) {
                PlaySoundEffect("click");
                isGameFullscreen = !isGameFullscreen;
                SDL_SetWindowFullscreen(window, isGameFullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
            }

            ImGui::Spacing();
            if (ImGui::Button("🔄 重置存档进度", ImVec2(300.0f, 32.0f))) {
                PlaySoundEffect("click");
                remove("save_game.dat");
                playerGold = 25;
                playerDeck = GetNationCards(playerNation);
                gachaResultMsg = "⚠️ 存档已重置！";
            }

            ImGui::End();

            if (showTacticalMenuDrawer) {
                ImGui::SetNextWindowPos(ImVec2(410.0f, currentWinH * 0.08f), ImGuiCond_Always);
                ImGui::SetNextWindowSize(ImVec2(currentWinW - 450.0f, currentWinH * 0.84f), ImGuiCond_Always);
                ImGui::Begin("🎖️ 战术作战与军需抽奖准备中心", &showTacticalMenuDrawer, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse);

                ImGui::TextColored(ImVec4(0.4f, 0.8f, 1.0f, 1.0f), "=== 1. 选择战场模式 ===");
                if (ImGui::Button("1v1 经典战役", ImVec2(150, 38))) { PlaySoundEffect("click"); gameMode = MODE_1V1; }
                ImGui::SameLine();
                if (ImGui::Button("2v2 集团军会战", ImVec2(150, 38))) { PlaySoundEffect("click"); gameMode = MODE_2V2; }
                ImGui::SameLine();
                if (ImGui::Button("大乱斗模式", ImVec2(150, 38))) { PlaySoundEffect("click"); gameMode = MODE_BATTLE_ROYALE; }
                ImGui::SameLine();
                if (ImGui::Button("🔥 丧尸坚守模式 (10波)", ImVec2(180, 38))) { PlaySoundEffect("click"); gameMode = MODE_ZOMBIE_STAND; enemyNation = NATION_ZOMBIE_HORDE; }

                ImGui::Separator();
                ImGui::TextColored(ImVec4(1.0f, 0.6f, 0.2f, 1.0f), "=== 2. 🎰 军需处抽奖商店 (概率获取稀有王牌兵种) ===");
                ImGui::TextWrapped("%s", gachaResultMsg.c_str());

                if (ImGui::Button("🎁 抽取战术补给箱 (Cost: 6 金币)", ImVec2(300, 42))) {
                    if (playerGold >= 6) {
                        playerGold -= 6;

                        int roll = rand() % 100;
                        RarityTier targetTier = TIER_NORMAL;
                        if (roll < 10) targetTier = TIER_LEGENDARY;
                        else if (roll < 40) targetTier = TIER_ADVANCED;

                        std::vector<int> poolIndices;
                        for (size_t i = 0; i < playerDeck.size(); ++i) {
                            if (!playerDeck[i].isGachaUnlocked && playerDeck[i].rarity == targetTier) {
                                poolIndices.push_back(static_cast<int>(i));
                            }
                        }
                        if (poolIndices.empty()) {
                            for (size_t i = 0; i < playerDeck.size(); ++i) {
                                if (!playerDeck[i].isGachaUnlocked) poolIndices.push_back(static_cast<int>(i));
                            }
                        }

                        if (!poolIndices.empty()) {
                            int rIdx = poolIndices[rand() % poolIndices.size()];
                            playerDeck[rIdx].isGachaUnlocked = true;
                            playerDeck[rIdx].isSelectedForDeck = true;
                            gachaResultMsg = "🎉 恭喜您抽中稀有兵种: [" + playerDeck[rIdx].nameCn + "]！已自动载入编制！";
                            PlaySoundEffect("gacha");
                        }
                        else {
                            gachaResultMsg = "✨ 您已解锁了全部军事兵种！溢出的金币转化为 4 点战场物资！";
                            playerSupply = std::min(10.0f, playerSupply + 4.0f);
                        }
                        SaveGameData(playerGold, playerDeck);
                    }
                    else {
                        PlaySoundEffect("click");
                        gachaResultMsg = "❌ 金币不足！请前往战役或丧尸模式获取战功金币！";
                    }
                }

                ImGui::Separator();
                ImGui::TextColored(ImVec4(0.4f, 1.0f, 0.4f, 1.0f), "=== 3. 编组您的战术卡牌 (最多选择上阵 8 支部队) ===");

                int colCount = 0;
                for (size_t i = 0; i < playerDeck.size(); ++i) {
                    if (!playerDeck[i].isGachaUnlocked) continue;

                    bool isSelected = playerDeck[i].isSelectedForDeck;
                    std::string btnLabel = playerDeck[i].nameCn + "\n" + (isSelected ? "[已上阵]" : "[备战中]");

                    if (ImGui::Button(btnLabel.c_str(), ImVec2(135, 55))) {
                        PlaySoundEffect("click");
                        int selectedCount = 0;
                        for (const auto& c : playerDeck) if (c.isSelectedForDeck) selectedCount++;

                        if (isSelected) {
                            if (selectedCount > 1) playerDeck[i].isSelectedForDeck = false;
                        }
                        else {
                            if (selectedCount < 8) playerDeck[i].isSelectedForDeck = true;
                        }
                        SaveGameData(playerGold, playerDeck);
                    }
                    colCount++;
                    if (colCount < 5) ImGui::SameLine();
                    else colCount = 0;
                }

                ImGui::Spacing();
                ImGui::Separator();
                if (ImGui::Button("🔥 确认编制 / 进军前线战场 (START BATTLE)", ImVec2(380, 50))) {
                    PlaySoundEffect("deploy");
                    gameState = STATE_PLAYING;
                    showTacticalMenuDrawer = false;
                    units.clear();
                    bullets.clear();
                    fortifications.clear();
                    smokeAreas.clear();
                    impactParticles.clear();
                    playerHQ.hp = playerHQ.maxHp = 4000;
                    enemyHQ.hp = enemyHQ.maxHp = 4000;
                    playerSupply = 6.0f;
                    currentZombieWave = 1;
                    waveInProgress = false;
                    waveSpawnIntervalTimer = 0.0f;
                    gameOver = false;
                }

                ImGui::End();
            }
        }
        else {
            ImGui::SetNextWindowPos(ImVec2(currentWinW - 280.0f, 20.0f), ImGuiCond_Always);
            ImGui::SetNextWindowSize(ImVec2(260.0f, 240.0f), ImGuiCond_Always);
            ImGui::Begin("前线部队存活监控", nullptr, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize);
            ImGui::TextColored(ImVec4(0.2f, 0.9f, 0.2f, 1.0f), "=== 我军战场兵种统计 ===");

            std::map<UnitType, int> unitCounts;
            for (const auto& u : units) {
                if (!u.isEnemyTeam && !u.isDead) unitCounts[u.uType]++;
            }

            for (const auto& card : playerDeck) {
                if (card.isSelectedForDeck && card.isGachaUnlocked) {
                    int count = unitCounts[card.uType];
                    ImGui::Text("%s: %d 人/单位", card.nameCn.c_str(), count);
                }
            }
            ImGui::End();

            ImGui::SetNextWindowPos(ImVec2(20.0f, 20.0f), ImGuiCond_Always);
            ImGui::SetNextWindowSize(ImVec2(160.0f, 50.0f), ImGuiCond_Always);
            ImGui::Begin("ExitMenu", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize);
            if (ImGui::Button("🚪 放弃战斗回主菜单", ImVec2(140, 32))) {
                PlaySoundEffect("click");
                gameState = STATE_MENU_SELECT;
                gameOver = false;
                showTacticalMenuDrawer = false;
            }
            ImGui::End();

            ImGui::SetNextWindowPos(ImVec2(0, currentWinH - 210.0f), ImGuiCond_Always);
            ImGui::SetNextWindowSize(ImVec2(currentWinW, 210.0f), ImGuiCond_Always);
            ImGui::Begin("Command Panel", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize);

            if (ImGui::Button("呼叫战术轰炸 (Cost:5)", ImVec2(150, 28))) activeSkill = SKILL_AIRSTRIKE;
            ImGui::SameLine();
            if (ImGui::Button("释放战术烟雾 (Cost:3)", ImVec2(150, 28))) { PlaySoundEffect("click"); activeSkill = SKILL_SMOKE_SCREEN; }

            ImGui::SameLine();
            if (ImGui::Checkbox("⚡全员指挥模式", &commandAllUnitsMode)) {
                PlaySoundEffect("click");
            }

            ImGui::SameLine();
            if (ImGui::Button("⚔️ 全军冲锋", ImVec2(80, 28))) {
                PlaySoundEffect("click");
                for (auto& u : units) if (!u.isEnemyTeam && (commandAllUnitsMode || u.isSelectedByPlayer)) {
                    u.currentOrder = ORDER_CHARGE;
                }
            }
            ImGui::SameLine();
            if (ImGui::Button("🎯 推进索敌", ImVec2(80, 28))) {
                PlaySoundEffect("click");
                for (auto& u : units) if (!u.isEnemyTeam && (commandAllUnitsMode || u.isSelectedByPlayer)) {
                    u.currentOrder = ORDER_ATTACK_MOVE;
                }
            }
            ImGui::SameLine();
            if (ImGui::Button("🚩 占领据点", ImVec2(80, 28))) {
                PlaySoundEffect("click");
                for (auto& u : units) if (!u.isEnemyTeam && (commandAllUnitsMode || u.isSelectedByPlayer)) {
                    u.currentOrder = ORDER_CAPTURE;
                }
            }
            ImGui::SameLine();
            if (ImGui::Button("🛡️ 原地防守", ImVec2(80, 28))) {
                PlaySoundEffect("click");
                for (auto& u : units) if (!u.isEnemyTeam && (commandAllUnitsMode || u.isSelectedByPlayer)) {
                    u.currentOrder = ORDER_DEFEND;
                }
            }

            bool hasSelectedPioneer = false;
            for (const auto& u : units) {
                if (!u.isEnemyTeam && u.isSelectedByPlayer && u.uType == UNIT_PIONEER) {
                    hasSelectedPioneer = true;
                    break;
                }
            }
            if (hasSelectedPioneer) {
                ImGui::SameLine();
                if (ImGui::Button("🏗️ [建造掩体]", ImVec2(110, 28))) {
                    for (auto& u : units) {
                        if (!u.isEnemyTeam && u.isSelectedByPlayer && u.uType == UNIT_PIONEER) {
                            fortifications.push_back({ u.x, u.y, 400, 400, false, true, 0.0f });
                            PlaySoundEffect("build");
                            SpawnImpactSparks(impactParticles, u.x, u.y, 12, { 220, 180, 100, 255 });
                        }
                    }
                }
            }

            ImGui::Separator();

            int activeIdx = 0;
            for (size_t i = 0; i < playerDeck.size(); ++i) {
                if (!playerDeck[i].isSelectedForDeck || !playerDeck[i].isGachaUnlocked) continue;

                int finalCost = playerDeck[i].supplyCost;
                std::string cardText = playerDeck[i].nameCn + "\n费用: " + std::to_string(finalCost);
                bool isChosen = (selectedCardIndex == (int)i);
                bool hasEnough = (playerSupply >= static_cast<float>(finalCost) && playerDeck[i].currentCooldown <= 0);

                ImGui::BeginGroup();
                if (isChosen) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.9f, 0.8f, 0.2f, 1.0f));
                else if (!hasEnough) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.3f, 0.3f, 0.3f, 1.0f));

                if (ImGui::Button(cardText.c_str(), ImVec2(110, 65))) {
                    if (hasEnough) {
                        PlaySoundEffect("click");
                        activeSkill = SKILL_NONE;
                        selectedCardIndex = isChosen ? -1 : static_cast<int>(i);
                    }
                }
                if (isChosen || !hasEnough) ImGui::PopStyleColor();

                std::string selectAllBtn = "全选[" + playerDeck[i].nameCn.substr(0, 4) + "]";
                if (ImGui::Button(selectAllBtn.c_str(), ImVec2(110, 22))) {
                    UnitType targetType = playerDeck[i].uType;
                    for (auto& u : units) {
                        if (!u.isEnemyTeam && u.uType == targetType) {
                            u.isSelectedByPlayer = true;
                        }
                    }
                    PlaySoundEffect("click");
                }
                ImGui::EndGroup();

                if (activeIdx < 8) ImGui::SameLine();
                activeIdx++;
            }

            ImGui::End();

            if (gameOver) {
                ImGui::SetNextWindowPos(ImVec2(currentWinW / 2.0f - 300.0f, currentWinH / 2.0f - 100.0f), ImGuiCond_Always);
                ImGui::SetNextWindowSize(ImVec2(600, 200), ImGuiCond_Always);
                ImGui::Begin("Game Over", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove);
                ImGui::Text("%s", winMessage.c_str());
                if (ImGui::Button("返回主指挥部 (Return to Menu)", ImVec2(280, 50))) {
                    PlaySoundEffect("click");
                    gameState = STATE_MENU_SELECT;
                    gameOver = false;
                    showTacticalMenuDrawer = false;
                }
                ImGui::End();
            }
        }

        if (gameState == STATE_PLAYING) {
            float shakeOffsetX = (cam.shakeIntensity > 0) ? (static_cast<float>(rand() % 10) - 5.0f) * (cam.shakeIntensity / 15.0f) : 0.0f;
            float shakeOffsetY = (cam.shakeIntensity > 0) ? (static_cast<float>(rand() % 10) - 5.0f) * (cam.shakeIntensity / 15.0f) : 0.0f;

            auto ToScreenX = [&](float wx) { return static_cast<int>(wx - cam.x + VIEW_WIDTH / 2.0f + shakeOffsetX); };
            auto ToScreenY = [&](float wy) { return static_cast<int>(wy - cam.y + VIEW_HEIGHT / 2.0f + shakeOffsetY); };

            // 渲染地图空气墙边界线
            SDL_SetRenderDrawColor(renderer, 38, 42, 35, 255);
            for (int i = 0; i < static_cast<int>(MAP_WIDTH); i += 180) {
                int sx = ToScreenX(static_cast<float>(i));
                if (sx >= 0 && sx <= static_cast<int>(VIEW_WIDTH)) SDL_RenderDrawLine(renderer, sx, 0, sx, static_cast<int>(VIEW_HEIGHT));
            }
            for (int j = 0; j < static_cast<int>(MAP_HEIGHT); j += 180) {
                int sy = ToScreenY(static_cast<float>(j));
                if (sy >= 0 && sy <= static_cast<int>(VIEW_HEIGHT)) SDL_RenderDrawLine(renderer, 0, sy, static_cast<int>(VIEW_WIDTH), sy);
            }

            // 绘制地图外围空气墙警戒红框
            SDL_SetRenderDrawColor(renderer, 100, 40, 40, 180);
            SDL_Rect borderWall = { ToScreenX(50.0f), ToScreenY(50.0f), static_cast<int>(MAP_WIDTH - 100.0f), static_cast<int>(MAP_HEIGHT - 100.0f) };
            SDL_RenderDrawRect(renderer, &borderWall);

            for (const auto& r : rivers) {
                SDL_SetRenderDrawColor(renderer, 30, 60, 90, 255);
                SDL_Rect rRect = { ToScreenX(r.x), ToScreenY(r.y), static_cast<int>(r.w), static_cast<int>(r.h) };
                SDL_RenderFillRect(renderer, &rRect);
            }
            for (const auto& b : bridges) {
                SDL_SetRenderDrawColor(renderer, 85, 75, 65, 255);
                SDL_Rect bRect = { ToScreenX(b.x), ToScreenY(b.y), static_cast<int>(b.w), static_cast<int>(b.h) };
                SDL_RenderFillRect(renderer, &bRect);
            }

            auto RenderHQ = [&](CapitolHQ& hq) {
                int hx = ToScreenX(hq.x);
                int hy = ToScreenY(hq.y);
                if (hx < -100 || hx > static_cast<int>(VIEW_WIDTH) + 100 || hy < -100 || hy > static_cast<int>(VIEW_HEIGHT) + 100) return;

                if (hq.flashTimer > 0) hq.flashTimer -= deltaTime;

                if (hq.flashTimer > 0) {
                    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
                }
                else {
                    SDL_SetRenderDrawColor(renderer, hq.isEnemyTeam ? 180 : 40, hq.isEnemyTeam ? 40 : 100, 40, 255);
                }

                SDL_Rect hqBase = { hx - 45, hy - 35, 90, 70 };
                SDL_RenderFillRect(renderer, &hqBase);
                SDL_SetRenderDrawColor(renderer, 255, 215, 0, 255);
                SDL_RenderDrawRect(renderer, &hqBase);

                SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
                SDL_Rect hqEb = { hx - 45, hy - 50, 90, 8 };
                SDL_RenderFillRect(renderer, &hqEb);
                SDL_SetRenderDrawColor(renderer, hq.isEnemyTeam ? 220 : 50, hq.isEnemyTeam ? 50 : 200, 50, 255);
                float hqHpRatio = static_cast<float>(hq.hp) / static_cast<float>(hq.maxHp);
                SDL_Rect hqEp = { hx - 45, hy - 50, static_cast<int>(90.0f * hqHpRatio), 8 };
                SDL_RenderFillRect(renderer, &hqEp);
                };
            RenderHQ(playerHQ);
            RenderHQ(enemyHQ);

            for (const auto& cp : capPoints) {
                int sx = ToScreenX(cp.x);
                int sy = ToScreenY(cp.y);
                SDL_Color capCol = (cp.owner == 0) ? SDL_Color{ 50, 120, 220, 255 } : ((cp.owner == 1) ? SDL_Color{ 220, 50, 50, 255 } : SDL_Color{ 160, 160, 160, 255 });
                SDL_SetRenderDrawColor(renderer, capCol.r, capCol.g, capCol.b, capCol.a);
                SDL_Rect zone = { sx - static_cast<int>(cp.radius), sy - static_cast<int>(cp.radius), static_cast<int>(cp.radius * 2.0f), static_cast<int>(cp.radius * 2.0f) };
                SDL_RenderDrawRect(renderer, &zone);

                SDL_SetRenderDrawColor(renderer, cp.owner == 0 ? 50 : (cp.owner == 1 ? 220 : 200), cp.owner == 0 ? 200 : 50, 50, 255);
                SDL_Rect flag = { sx - 12, sy - 26, 24, 24 };
                SDL_RenderFillRect(renderer, &flag);
            }

            for (const auto& sm : smokeAreas) {
                if (sm.active) {
                    int smx = ToScreenX(sm.x);
                    int smy = ToScreenY(sm.y);
                    SDL_SetRenderDrawColor(renderer, 200, 200, 200, 160);
                    SDL_Rect smRect = { smx - static_cast<int>(sm.radius), smy - static_cast<int>(sm.radius), static_cast<int>(sm.radius * 2.0f), static_cast<int>(sm.radius * 2.0f) };
                    SDL_RenderFillRect(renderer, &smRect);
                }
            }

            for (const auto& fort : fortifications) {
                int fx = ToScreenX(fort.x);
                int fy = ToScreenY(fort.y);
                if (fx < -50 || fx > static_cast<int>(VIEW_WIDTH) + 50 || fy < -50 || fy > static_cast<int>(VIEW_HEIGHT) + 50) continue;

                if (fort.flashTimer > 0) {
                    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
                }
                else {
                    SDL_SetRenderDrawColor(renderer, 140, 120, 80, 255);
                }
                SDL_Rect fortRect = { fx - 22, fy - 10, 44, 20 };
                SDL_RenderFillRect(renderer, &fortRect);
                SDL_SetRenderDrawColor(renderer, 80, 60, 40, 255);
                SDL_RenderDrawRect(renderer, &fortRect);
            }

            for (const auto& p : impactParticles) {
                if (p.active) {
                    int px = ToScreenX(p.x);
                    int py = ToScreenY(p.y);
                    SDL_SetRenderDrawColor(renderer, p.color.r, p.color.g, p.color.b, p.color.a);
                    SDL_Rect pr = { px - 2, py - 2, 4, 4 };
                    SDL_RenderFillRect(renderer, &pr);
                }
            }

            if (selectedCardIndex != -1 || activeSkill != SKILL_NONE) {
                int rawMx, rawMy;
                SDL_GetMouseState(&rawMx, &rawMy);
                float logicalX = 0.0f, logicalY = 0.0f;
                SDL_RenderWindowToLogical(renderer, rawMx, rawMy, &logicalX, &logicalY);

                if (logicalY < 710.0f) {
                    SDL_SetRenderDrawColor(renderer, activeSkill != SKILL_NONE ? 255 : 50, activeSkill != SKILL_NONE ? 80 : 255, 50, 200);
                    SDL_Rect previewCursor = { static_cast<int>(logicalX) - 30, static_cast<int>(logicalY) - 30, 60, 60 };
                    SDL_RenderDrawRect(renderer, &previewCursor);
                }
            }

            for (const auto& u : units) {
                int ux = ToScreenX(u.x);
                int uy = ToScreenY(u.y);
                if (u.isDead || ux < -40 || ux > static_cast<int>(VIEW_WIDTH) + 40 || uy < -40 || uy > static_cast<int>(VIEW_HEIGHT) + 40) continue;

                RenderDetailedGameUnit(renderer, u, ux, uy);

                // 生命值血条
                SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
                SDL_Rect eb = { ux - 16, uy - 30, 32, 4 };
                SDL_RenderFillRect(renderer, &eb);
                SDL_SetRenderDrawColor(renderer, u.isEnemyTeam ? 220 : 50, u.isEnemyTeam ? 50 : 200, 50, 255);
                float hpRatio = static_cast<float>(u.hp) / static_cast<float>(u.maxHp);
                SDL_Rect ep = { ux - 16, uy - 30, static_cast<int>(32.0f * hpRatio), 4 };
                SDL_RenderFillRect(renderer, &ep);

                if (u.suppressionValue > 10.0f) {
                    SDL_SetRenderDrawColor(renderer, 255, 50, 50, 255);
                    float supRatio = std::min(1.0f, u.suppressionValue / 100.0f);
                    SDL_Rect supBar = { ux - 16, uy - 35, static_cast<int>(32.0f * supRatio), 3 };
                    SDL_RenderFillRect(renderer, &supBar);
                }

                if (u.isReloading && u.reloadTimeMax > 0) {
                    SDL_SetRenderDrawColor(renderer, 255, 200, 0, 255);
                    float reloadRatio = 1.0f - (u.currentReloadTimer / u.reloadTimeMax);
                    SDL_Rect reloadBar = { ux - 16, uy - 39, static_cast<int>(32.0f * reloadRatio), 3 };
                    SDL_RenderFillRect(renderer, &reloadBar);
                }
            }

            for (const auto& bl : bullets) {
                if (bl.active) {
                    SDL_SetRenderDrawColor(renderer, 255, 240, 150, 255);
                    SDL_Rect bulletRect = { ToScreenX(bl.x) - 2, ToScreenY(bl.y) - 2, 4, 4 };
                    SDL_RenderFillRect(renderer, &bulletRect);
                }
            }
        }

        ImGui::Render();
        ImGui_ImplSDLRenderer2_RenderDrawData(ImGui::GetDrawData(), renderer);

        SDL_RenderPresent(renderer);
        SDL_Delay(12);
    }

    ImGui_ImplSDLRenderer2_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}